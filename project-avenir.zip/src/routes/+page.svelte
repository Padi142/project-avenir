<div class="flex flex-col gap-4 justify-center items-center h-screen">
	<p class="text-7xl py-5 font-archivo-narrow">I think it's happening...</p>
	<p class="text-5xl py-4">Will you be a part of this ?</p>
	<p class="text-2xl py-2">Or you will just look...</p>
	<p class="text-xl py-1">Like everyone else</p>
	<a href="/codes" class="text-sm mt-10">Start</a>
</div>
