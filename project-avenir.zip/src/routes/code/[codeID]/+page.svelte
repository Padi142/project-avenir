<div class="flex flex-col gap-4 justify-center items-center h-screen">
	<p class="text-4xl py-1">You found it! Congrats!</p>
</div>
