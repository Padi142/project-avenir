<div class="flex flex-col gap-4 justify-center items-center">
	<img
		class="h-1/2 w-1/4"
		src="https://paulcrickard.files.wordpress.com/2012/02/img001_2448x3264.jpg"
		alt="Somar"
	/>
	<p class="text-xl py-1">Don't be afraid, try it</p>
</div>
