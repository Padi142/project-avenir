<script>
	import '../app.css';
</script>

<nav>
	<div class="flex justify-between">
		<a href="/" class="text-bold ml-10 mt-4"> Avenir </a>
	</div>
</nav>

<slot />
